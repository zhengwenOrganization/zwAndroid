package com.db.view;

import com.db.R;

import android.app.AlertDialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class DialogView extends AlertDialog {

	private View.OnClickListener addListener, updateListener, deleteListener;
	private String message;

	public DialogView(Context context, boolean cancelable, OnCancelListener cancelListener) {
		super(context, cancelable, cancelListener);
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.dialog_confirm);
		initView();
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public void setAddClickListener(View.OnClickListener listener) {
		this.addListener = listener;
	}

	public void setUpdateClickListener(View.OnClickListener listener) {
		this.updateListener = listener;
	}

	public void setDeleteClickListener(View.OnClickListener listener) {
		this.deleteListener = listener;
	}

	private void initView() {
		TextView tvMessage = (TextView) findViewById(R.id.tv_details);
		findViewById(R.id.btn_add).setOnClickListener(addListener);
		findViewById(R.id.btn_update).setOnClickListener(updateListener);
		findViewById(R.id.btn_delete).setOnClickListener(deleteListener);
		tvMessage.setText(message);
	}

	public static boolean isNullEmptyBlank(String str) {
		if (str == null || "".equals(str) || "".equals(str.trim()))
			return true;
		return false;
	}

}
