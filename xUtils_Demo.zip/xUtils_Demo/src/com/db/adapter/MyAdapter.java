package com.db.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.db.R;
import com.db.bean.People;

import java.util.List;

public class MyAdapter extends BaseAdapter {

	private List<People> people;
	private LayoutInflater inflater;

	public MyAdapter(Context context, List<People> people) {
		this.people = people;
		this.inflater = LayoutInflater.from(context);
	}

	public void setUserEntities(List<People> people) {
		this.people = people;
		this.notifyDataSetChanged();
	}

	@Override
	public int getCount() {
		return people.size();
	}

	@Override
	public Object getItem(int position) {
		return people.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		Viewholder viewholder = null;
		if (convertView == null) {
			convertView = inflater.inflate(R.layout.item, parent, false);
			viewholder = new Viewholder(convertView);
			convertView.setTag(viewholder);
		} else {
			viewholder = (Viewholder) convertView.getTag();
		}
		People entity = people.get(position);
		viewholder.tv_id.setText(entity.getId() + "");
		viewholder.tv_name.setText(entity.getName());
		viewholder.tv_address.setText(entity.getAddress());
		viewholder.tv_arg.setText(entity.getAge() + "");
		viewholder.tv_sex.setText(entity.getSex());
		return convertView;
	}

	class Viewholder {
		private TextView tv_id;
		private TextView tv_name;
		private TextView tv_address;
		private TextView tv_arg;
		private TextView tv_sex;

		private Viewholder(View view) {
			tv_id = (TextView) view.findViewById(R.id.tv_id);
			tv_name = (TextView) view.findViewById(R.id.tv_name);
			tv_address = (TextView) view.findViewById(R.id.tv_address);
			tv_arg = (TextView) view.findViewById(R.id.tv_arg);
			tv_sex = (TextView) view.findViewById(R.id.tv_sex);
		}
	}

}
