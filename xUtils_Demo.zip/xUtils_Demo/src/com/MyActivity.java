package com;

import java.util.ArrayList;
import java.util.List;

import com.db.DbHelper;
import com.db.R;
import com.db.adapter.MyAdapter;
import com.db.bean.People;
import com.db.view.DialogView;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

/*
 * https://github.com/wyouflf/xUtils
 */
public class MyActivity extends Activity implements OnClickListener {

	private ListView listview;
	private MyAdapter adapter;
	private DbHelper dbHelper;
	private EditText etSelect;
	private List<People> pList = new ArrayList<People>();
	private People entity = null;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		findViewById(R.id.btn_create).setOnClickListener(this);
		findViewById(R.id.btn_select).setOnClickListener(this);
		findViewById(R.id.btn_searchdesc).setOnClickListener(this);

		findViewById(R.id.btn_selectname).setOnClickListener(this);
		findViewById(R.id.btn_selectlike).setOnClickListener(this);
		etSelect = (EditText) findViewById(R.id.et_select);
		listview = (ListView) findViewById(R.id.listview);

		dbHelper = DbHelper.getInstance(this);
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		// getData();// 造数据
		adapter = new MyAdapter(this, pList);
		listview.setAdapter(adapter);
		listview.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
				// TODO Auto-generated method stub
				showAlertDialog(arg2);
			}
		});
		select();// 数据库查询所有数据
	}

	private void showAlertDialog(final int position) {
		final DialogView dialog = new DialogView(this, true, null);
		entity = pList.get(position);
		dialog.setMessage(entity.toString());
		dialog.setAddClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				save();
				dialog.dismiss();
			}
		});
		dialog.setUpdateClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				addDialog(position);
				dialog.dismiss();
			}
		});
		dialog.setDeleteClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				delete(entity.getId());
				dialog.dismiss();
			}
		});
		dialog.show();
	}

	private void addDialog(int position) {
		entity = pList.get(position);
		final AlertDialog dialog = new AlertDialog.Builder(this).create();
		dialog.setView(LayoutInflater.from(this).inflate(R.layout.dialog_add, null));
		dialog.show();
		dialog.getWindow().setContentView(R.layout.dialog_add);
		Button btnPositive = (Button) dialog.findViewById(R.id.btn_submit);
		Button btnNegative = (Button) dialog.findViewById(R.id.btn_cancel);
		final EditText etContent = (EditText) dialog.findViewById(R.id.et_name);
		etContent.setText(entity.getName());
		btnPositive.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				String name = etContent.getText().toString().trim();
				if (DialogView.isNullEmptyBlank(name)) {
					etContent.setError("输入内如不能为空");
				} else {
					update(entity.getId(), name);
					dialog.dismiss();
				}
			}
		});
		btnNegative.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				dialog.dismiss();
			}
		});
	}

	@Override
	public void onClick(View view) {
		switch (view.getId()) {
		case R.id.btn_create:
			create();
			break;
		case R.id.btn_select:
			select();
			break;
		case R.id.btn_searchdesc:
			searchDesc();
			break;
		case R.id.btn_selectname:
			String nameStr = etSelect.getText().toString().trim();
			if (0 < nameStr.length()) {
				selectName(nameStr);
			}
			break;
		case R.id.btn_selectlike:
			String nameLike = etSelect.getText().toString().trim();
			if (0 < nameLike.length()) {
				selectLike(nameLike);
			}
			break;
		}
	}

	// 增加
	private void save() {
		entity = new People();
		entity.setName("小雨");
		entity.setAge(25);
		entity.setSex("女");
		entity.setAddress("深圳");
		boolean isTrue = dbHelper.save(entity);
		if (isTrue) {
			searchDesc();
			showToast("添加成功");
		} else {
			showToast("添加失败");
		}
	}

	// 删除 根据id删除
	private void delete(int id) {
		boolean isTrue = dbHelper.deleteCriteria(People.class, "id", id);
		if (isTrue) {
			select();
			showToast("删除成功");
		} else {
			showToast("删除失败");
		}
	}

	// 修改 根据id修改name
	private void update(int id, String name) {
		entity = (People) dbHelper.searchOne(People.class, "id", id);
		entity.setName(name);
		boolean isTrue1 = dbHelper.update(entity, "name");
		if (isTrue1) {
			select();
			showToast("修改成功");
		} else {
			showToast("修改失败");
		}
	}

	// 根据条件name查询
	private void selectLike(String name) {
		pList.clear();
		pList = dbHelper.searchLike(People.class, "name", name);
		if (pList != null) {
			adapter.setUserEntities(pList);
		}
	}

	// 根据条件name查询
	private void selectName(String name) {
		pList.clear();
		entity = (People) dbHelper.searchOne(People.class, "name", name);
		if ((pList != null) && (entity != null)) {
			pList.add(entity);
			adapter.setUserEntities(pList);
		}
	}

	// 正叙 查询所有
	private void select() {
		pList.clear();
		pList = dbHelper.search(People.class);
		if (pList != null) {
			adapter.setUserEntities(pList);
		}
	}

	// 倒叙 查询所有
	private void searchDesc() {
		pList.clear();
		pList = dbHelper.searchDesc(People.class);
		if (pList != null) {
			adapter.setUserEntities(pList);
		}
	}

	// 创建 插入全部对象
	private void create() {
		boolean isTrue = dbHelper.saveAll(pList);
		if (isTrue) {
			showToast("创建成功");
		} else {
			showToast("创建失败");
		}
	}

	private void showToast(String name) {
		Toast.makeText(this, name, Toast.LENGTH_SHORT).show();
	}

	@Override
	protected void onStop() {
		// TODO Auto-generated method stub
		super.onStop();
		pList = null;
		entity = null;
	}

	// 造数据
	private void getData() {
		for (int i = 0; i < 1000; i++) {
			entity = new People();
			entity.setId(i);
			entity.setName("小明" + i);
			entity.setAddress("上海");
			entity.setAge(15 + i);
			entity.setSex("男");
			pList.add(entity);
		}
	}

}
